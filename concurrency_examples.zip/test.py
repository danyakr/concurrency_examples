import gevent
from gevent import monkey
import time

monkey.patch_all()


def task(name):
    print(f"[{name}] Start")
    time.sleep(2)  # Не будет заблокировано благодаря monkey patching
    print(f"[{name}] End")


# Создаём зелёные потоки
g1 = gevent.spawn(task, "Task 1")
g2 = gevent.spawn(task, "Task 2")

# Ожидание завершения
gevent.joinall([g1, g2])
