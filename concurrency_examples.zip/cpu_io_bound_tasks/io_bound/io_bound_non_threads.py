import requests
import time

urls = [
    "https://example.com/",
    "https://example.com/",
    "https://example.com/",
    "https://example.com/",
]


def fetch(url):
    print(f"Start fetching {url}")
    response = requests.get(url)
    print(f"Done fetching {url} with status {response.status_code}")


start = time.time()

for url in urls:
    fetch(url)

print(f"Total time: {time.time() - start:.2f} seconds")
