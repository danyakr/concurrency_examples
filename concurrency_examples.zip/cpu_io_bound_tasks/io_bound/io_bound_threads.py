import threading
import requests
import time

urls = [
    "https://example.com/",
    "https://example.com/",
    "https://example.com/",
    "https://example.com/",
]


def fetch(url):
    print(f"Start fetching {url}")
    response = requests.get(url)
    print(f"Done fetching {url} with status {response.status_code}")


start = time.time()

threads = []
for url in urls:
    thread = threading.Thread(target=fetch, args=(url,))
    thread.start()
    threads.append(thread)

for thread in threads:
    thread.join()

print(f"Total time: {time.time() - start:.2f} seconds")
