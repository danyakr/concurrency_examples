import time


def compute_pi(n_terms):
    pi = 0
    for k in range(n_terms):
        pi += (-1)**k / (2 * k + 1)
    return 4 * pi


def worker(n_terms):
    print(f"Computing π with {n_terms} terms...")
    result = compute_pi(n_terms)
    print(f"Approximate π = {result}")


start = time.time()

# Последовательный запуск
for _ in range(3):
    worker(5_000_000)

print(f"Total time (no threads): {time.time() - start:.2f} seconds")
