from multiprocessing import Process
import time


def compute_pi(n_terms):
    pi = 0
    for k in range(n_terms):
        pi += (-1)**k / (2 * k + 1)
    return 4 * pi


def worker(n_terms):
    print(f"Computing π with {n_terms} terms...")
    result = compute_pi(n_terms)
    print(f"Approximate π = {result}")


if __name__ == '__main__':
    start = time.time()

    processes = []
    for _ in range(3):
        p = Process(target=worker, args=(5_000_000,))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

    print(f"Total time (processes): {time.time() - start:.2f} seconds")
