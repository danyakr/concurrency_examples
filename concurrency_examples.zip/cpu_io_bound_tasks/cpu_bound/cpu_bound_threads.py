import threading
import time


def compute_pi(n_terms):
    pi = 0
    for k in range(n_terms):
        pi += (-1)**k / (2 * k + 1)
    return 4 * pi


def worker(n_terms):
    print(f"Computing π with {n_terms} terms...")
    result = compute_pi(n_terms)
    print(f"Approximate π = {result}")


start = time.time()

threads = []
for _ in range(3):
    t = threading.Thread(target=worker, args=(5_000_000,))
    t.start()
    threads.append(t)

for t in threads:
    t.join()

print(f"Total time (threads): {time.time() - start:.2f} seconds")
