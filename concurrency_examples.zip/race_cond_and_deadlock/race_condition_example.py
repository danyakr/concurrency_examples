import threading

# Общий ресурс
counter = 0


# Функция для увеличения счетчика на 1
def increment():
    global counter
    for _ in range(1_000_000):  # Увеличиваем счетчик много раз
        counter += 1
        counter += int(1)


# Создаем два потока, которые будут увеличивать счетчик
thread1 = threading.Thread(target=increment)
thread2 = threading.Thread(target=increment)

# Запускаем потоки
thread1.start()
thread2.start()

# Ждем завершения потоков
thread1.join()
thread2.join()

# Выводим значение счетчика
print("Counter value:", counter)
