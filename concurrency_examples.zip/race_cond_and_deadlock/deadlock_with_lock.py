import threading
from threading import Thread

counter = [0]
lock = threading.Lock()


def inc():
    lock.acquire()
    c = counter[0]
    counter[0] = c + 1
    # lock.release()


threads = [Thread(target=inc) for _ in range(2)]

for t in threads:
    t.start()
for t in threads:
    t.join()

print(counter)
