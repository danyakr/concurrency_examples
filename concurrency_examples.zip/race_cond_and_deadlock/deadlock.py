import threading
import time

lock_a = threading.Lock()
lock_b = threading.Lock()


def thread1():
    with lock_a:
        print("Поток 1 захватил lock_a")
        time.sleep(1)
        print("Поток 1 пытается захватить lock_b")
        with lock_b:
            print("Поток 1 захватил оба ресурса")


def thread2():
    with lock_b:
        print("Поток 2 захватил lock_b")
        time.sleep(1)
        print("Поток 2 пытается захватить lock_a")
        with lock_a:
            print("Поток 2 захватил оба ресурса")


t1 = threading.Thread(target=thread1)
t2 = threading.Thread(target=thread2)

t1.start()
t2.start()
t1.join()
t2.join()
