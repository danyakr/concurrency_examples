import time
from threading import Thread

counter = [0]


def inc():
    c = counter[0]
    time.sleep(0.1)
    counter[0] = c + 1


threads = [Thread(target=inc) for _ in range(100)]

for t in threads:
    t.start()
for t in threads:
    t.join()

print(counter)
