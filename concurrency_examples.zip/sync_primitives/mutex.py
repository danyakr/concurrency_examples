import threading

lock = threading.Lock()
counter = 0


def increment():
    global counter
    for _ in range(10_000):
        with lock:  # Только один поток заходит внутрь одновременно
            counter += int(1)


threads = [threading.Thread(target=increment) for _ in range(10)]

for t in threads:
    t.start()
for t in threads:
    t.join()

print(counter)  # Без lock результат был бы непредсказуем
