import threading
import time

sem = threading.Semaphore(3)  # Разрешено максимум 3 потока одновременно


def limited_access(thread_id):
    with sem:
        print(f"Поток {thread_id} начал работу ")
        time.sleep(1)
        print(f"Поток {thread_id} закончил работу ")


threads = [threading.Thread(target=limited_access, args=(i,)) for i in range(6)]

for t in threads:
    t.start()
for t in threads:
    t.join()
