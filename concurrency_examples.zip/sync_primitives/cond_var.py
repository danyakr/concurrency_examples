import threading
import time

queue = []
condition = threading.Condition()


def producer():
    with condition:
        print("Производитель добавляет элемент")
        queue.append(1)
        condition.notify()  # Оповещаем потребителя


def consumer():
    with condition:
        while not queue:
            print("Потребитель ждет")
            condition.wait()  # Ждёт, пока не появится элемент
        print("Потребитель получил элемент")


t1 = threading.Thread(target=consumer)
t2 = threading.Thread(target=producer)

t1.start()
time.sleep(1)
t2.start()

t1.join()
t2.join()
