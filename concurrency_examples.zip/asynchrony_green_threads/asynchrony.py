import asyncio
import time


# def gen():
#     x = 10
#     print(x)
#     yield x
#
#
# async def example():
#     print(100)
#
# print(gen())
# print(example())


async def task_one():
    print('Task one start')
    await asyncio.sleep(1)
    print('Task one finish')


async def task_two():
    print('Task two start')
    await asyncio.sleep(2)
    print('Task two finish')


async def task_three():
    print('Task three start')
    await asyncio.sleep(3)
    print('Task three finish')


async def main():
    await asyncio.gather(task_one(), task_two(), task_three())

start = time.time()
asyncio.run(main())
print(time.time() - start)
