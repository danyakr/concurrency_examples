import asyncio
import time
from concurrent.futures import ThreadPoolExecutor


# Синхронная блокирующая функция
def blocking_task():
    print("[blocking_task] Start (runs in separate thread)")
    time.sleep(2)
    print("[blocking_task] Done")
    return "blocking result"


# Асинхронная функция, которая работает параллельно
async def async_worker():
    for i in range(5):
        print(f"[async_worker] Tick {i}")
        await asyncio.sleep(1)


# Точка входа
async def main():
    loop = asyncio.get_running_loop()

    with ThreadPoolExecutor() as pool:
        # Запуск блокирующей и асинхронной задачи
        blocking_future = loop.run_in_executor(pool, blocking_task)
        async_future = async_worker()

        # Ожидание выполнения задач
        result = await asyncio.gather(blocking_future, async_future)
        print(f"[main] Result: {result[0]}")

# Запуск
asyncio.run(main())
