import asyncio
import aiohttp
import time


async def fetch(session, url, n):
    async with session.get(url) as response:
        await response.text()
        print(f"Coroutine {n} done")


async def main():
    async with aiohttp.ClientSession() as session:
        tasks = [fetch(session, "https://example.com", i) for i in range(10)]
        await asyncio.gather(*tasks)

start = time.time()
asyncio.run(main())
print(f"Asyncio done in {time.time() - start:.2f} seconds")
