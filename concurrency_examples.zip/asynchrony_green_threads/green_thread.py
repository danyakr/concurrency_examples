import gevent
from gevent import monkey
import requests
import time

# Патч стандартных блокирующих модулей (вроде socket, time и т.п.)
monkey.patch_all()


def fetch(url, n):
    response = requests.get(url)
    print(f"Green thread {n} done")


start = time.time()
tasks = [gevent.spawn(fetch, "https://example.com", i) for i in range(10)]
gevent.joinall(tasks)
print(f"Gevent done in {time.time() - start:.2f} seconds")
