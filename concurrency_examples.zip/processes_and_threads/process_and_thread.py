import os
import threading
from time import sleep

print(f'Исполняется Python-процесс с PID: {os.getpid()}')

total_threads = threading.active_count()
thread_name = threading.current_thread().name

print(f'В данный момент Python исполняет {total_threads} поток(ов)')
print(f'Имя текущего потока {thread_name}')
sleep(15)
