import threading
import time


def hello_from_thread():
    print(f'Поток {threading.current_thread()} TID потока {threading.current_thread().ident}')
    time.sleep(0.1)


t = threading.Thread(target=hello_from_thread)
t.start()

total_threads = threading.active_count()
thread_name = threading.current_thread().name
tid = threading.current_thread().ident

print(f'В данный момент Python выполняет {total_threads} поток(ов)')
print(f'Имя текущего потока {thread_name} TID потока {tid}')

t.join()
