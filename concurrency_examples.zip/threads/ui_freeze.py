import tkinter as tk
import time


def long_task():
    print("Starting long task...")
    time.sleep(5)
    print("Task done.")
    label.config(text="Задача завершена")


def on_click():
    label.config(text="Выполняется задача...")
    long_task()


root = tk.Tk()
root.title("UI freeze")
root.minsize(300, 200)

label = tk.Label(root, text="Нажмите кнопку для запуска задачи")
label.pack(pady=20)

button = tk.Button(root, text="Старт", command=on_click)
button.pack(pady=10)

root.mainloop()
