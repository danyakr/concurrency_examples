import tkinter as tk
import threading
import time


def long_task():
    print("Starting long task...")
    time.sleep(5)
    print("Task done.")
    root.after(0, lambda: label.config(text="Задача завершена"))


def on_click():
    label.config(text="Выполняется задача...")
    thread = threading.Thread(target=long_task)
    thread.start()


root = tk.Tk()
root.title("UI responsive")
root.minsize(300, 200)  # Установка минимального размера окна

label = tk.Label(root, text="Нажмите кнопку для запуска задачи")
label.pack(pady=20)

button = tk.Button(root, text="Старт", command=on_click)
button.pack(pady=10)

root.mainloop()
